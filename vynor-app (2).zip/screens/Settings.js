import React from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { useTheme } from '../context/ThemeContext';

export default function Settings() {
  const { isDarkMode, toggleTheme } = useTheme();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 20,
      backgroundColor: isDarkMode ? '#121212' : '#F0F0F0',
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
      color: isDarkMode ? '#FFFFFF' : '#333333',
    },
    settingItem: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 15,
      borderBottomWidth: 1,
      borderBottomColor: isDarkMode ? '#333333' : '#E0E0E0',
    },
    settingText: {
      fontSize: 18,
      color: isDarkMode ? '#FFFFFF' : '#333333',
    },
    button: {
      backgroundColor: '#4CAF50',
      padding: 15,
      borderRadius: 10,
      alignItems: 'center',
      marginTop: 20,
    },
    buttonText: {
      color: '#FFFFFF',
      fontSize: 18,
      fontWeight: 'bold',
    },
  });

  const handleCalibrate = () => {
    Alert.alert(
      "Calibración",
      "¿Estás seguro de que deseas calibrar los sensores?",
      [
        {
          text: "Cancelar",
          style: "cancel"
        },
        { 
          text: "Calibrar", 
          onPress: () => {
            // Aquí iría la lógica para calibrar los sensores
            Alert.alert("Calibración completada", "Los sensores han sido calibrados exitosamente.");
          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Configuración</Text>
      
      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Modo Oscuro</Text>
        <Switch
          value={isDarkMode}
          onValueChange={toggleTheme}
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={isDarkMode ? "#f5dd4b" : "#f4f3f4"}
        />
      </View>
      
      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Notificaciones</Text>
        <Switch
          value={true}
          onValueChange={() => {}}
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={"#f5dd4b"}
        />
      </View>
      
      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Intervalo de actualización</Text>
        <Text style={styles.settingText}>5s</Text>
      </View>
      
      <TouchableOpacity style={styles.button} onPress={handleCalibrate}>
        <Text style={styles.buttonText}>Calibrar Sensores</Text>
      </TouchableOpacity>
    </View>
  );
}

