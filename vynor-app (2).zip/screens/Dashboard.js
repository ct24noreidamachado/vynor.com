import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity, Animated } from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import Icon from 'react-native-vector-icons/Ionicons';
import { useTheme } from '../context/ThemeContext';

export default function Dashboard() {
  const [encendido, setEncendido] = useState(false);
  const [calidadAire, setCalidadAire] = useState(0);
  const [nivelOxigeno, setNivelOxigeno] = useState(0);
  const [bateria, setBateria] = useState(100);
  const [emergencyMode, setEmergencyMode] = useState(false);
  const { isDarkMode, toggleTheme } = useTheme();

  const batteryAnimation = new Animated.Value(bateria);

  useEffect(() => {
    if (encendido) {
      const interval = setInterval(() => {
        setCalidadAire(Math.random() * 100);
        setNivelOxigeno(Math.random() * 100);
        setBateria(prev => Math.max(0, prev - 0.1));
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [encendido]);

  useEffect(() => {
    Animated.timing(batteryAnimation, {
      toValue: bateria,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [bateria]);

  const toggleEmergencyMode = () => {
    setEmergencyMode(!emergencyMode);
    // Aquí iría la lógica para activar el modo de emergencia en el traje
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 20,
      backgroundColor: isDarkMode ? '#121212' : '#F0F0F0',
    },
    title: {
      fontSize: 28,
      fontWeight: 'bold',
      color: isDarkMode ? '#FFFFFF' : '#333333',
      marginBottom: 10,
    },
    card: {
      backgroundColor: isDarkMode ? '#1E1E1E' : '#FFFFFF',
      borderRadius: 10,
      padding: 15,
      marginBottom: 15,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 5,
    },
    cardTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      marginBottom: 10,
      color: isDarkMode ? '#FFFFFF' : '#333333',
    },
    row: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    batteryContainer: {
      width: '100%',
      height: 20,
      backgroundColor: isDarkMode ? '#333333' : '#E0E0E0',
      borderRadius: 10,
      overflow: 'hidden',
    },
    batteryLevel: {
      height: '100%',
      backgroundColor: '#4CAF50',
    },
    emergencyButton: {
      backgroundColor: emergencyMode ? '#FF5252' : '#4CAF50',
      padding: 15,
      borderRadius: 10,
      alignItems: 'center',
      marginTop: 15,
    },
    emergencyButtonText: {
      color: '#FFFFFF',
      fontSize: 18,
      fontWeight: 'bold',
    },
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>VYNOR Dashboard</Text>
      
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Estado del Traje</Text>
        <View style={styles.row}>
          <Text style={{color: isDarkMode ? '#FFFFFF' : '#333333'}}>Encendido</Text>
          <Switch 
            value={encendido} 
            onValueChange={setEncendido}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={encendido ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Calidad del Aire</Text>
        <LineChart
          data={{
            labels: ["1m", "2m", "3m", "4m", "5m"],
            datasets: [{ data: [
              Math.random() * 100,
              Math.random() * 100,
              Math.random() * 100,
              Math.random() * 100,
              calidadAire
            ]}]
          }}
          width={300}
          height={200}
          chartConfig={{
            backgroundColor: isDarkMode ? '#1E1E1E' : '#FFFFFF',
            backgroundGradientFrom: isDarkMode ? '#1E1E1E' : '#FFFFFF',
            backgroundGradientTo: isDarkMode ? '#1E1E1E' : '#FFFFFF',
            decimalPlaces: 2,
            color: (opacity = 1) => `rgba(76, 175, 80, ${opacity})`,
            style: {
              borderRadius: 16
            }
          }}
          bezier
          style={{
            marginVertical: 8,
            borderRadius: 16
          }}
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Nivel de Oxígeno</Text>
        <Text style={{fontSize: 24, color: isDarkMode ? '#FFFFFF' : '#333333'}}>{nivelOxigeno.toFixed(1)}%</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Batería</Text>
        <View style={styles.batteryContainer}>
          <Animated.View 
            style={[
              styles.batteryLevel, 
              {
                width: batteryAnimation.interpolate({
                  inputRange: [0, 100],
                  outputRange: ['0%', '100%']
                })
              }
            ]} 
          />
        </View>
        <Text style={{textAlign: 'center', marginTop: 5, color: isDarkMode ? '#FFFFFF' : '#333333'}}>{bateria.toFixed(1)}%</Text>
      </View>

      <TouchableOpacity style={styles.emergencyButton} onPress={toggleEmergencyMode}>
        <Text style={styles.emergencyButtonText}>
          {emergencyMode ? 'Desactivar' : 'Activar'} Modo de Emergencia
        </Text>
      </TouchableOpacity>
    </View>
  );
}

