import React, { useState, useEffect } from 'react'
import { useTheme } from '../context/ThemeContext'
import { Card } from './ui/card'
import { Button } from './ui/button'
import { Switch } from './ui/switch'
import { Progress } from './ui/progress'
import { AirVent, Battery, Gauge, Thermometer } from 'lucide-react'

export default function Dashboard() {
  const [encendido, setEncendido] = useState(false)
  const [calidadAire, setCalidadAire] = useState(0)
  const [nivelOxigeno, setNivelOxigeno] = useState(0)
  const [velocidadVentilador, setVelocidadVentilador] = useState(0)
  const [bateria, setBateria] = useState(100)
  const { isDarkMode } = useTheme()

  useEffect(() => {
    if (encendido) {
      const interval = setInterval(() => {
        setCalidadAire(Math.random() * 100)
        setNivelOxigeno(Math.random() * 100)
        setBateria(prev => Math.max(0, prev - 0.1))
      }, 5000)
      return () => clearInterval(interval)
    }
  }, [encendido])

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold text-gray-800 dark:text-white">VYNOR Dashboard</h1>
      
      <Card>
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-2">Estado del Traje</h2>
          <div className="flex items-center justify-between">
            <span>Encendido</span>
            <Switch checked={encendido} onCheckedChange={setEncendido} />
          </div>
        </div>
      </Card>

      <Card>
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-2 flex items-center">
            <Gauge className="mr-2" />
            Calidad del Aire
          </h2>
          <Progress value={calidadAire} className="w-full" />
          <span className="text-sm mt-1 block">{calidadAire.toFixed(1)}%</span>
        </div>
      </Card>

      <Card>
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-2 flex items-center">
            <Thermometer className="mr-2" />
            Nivel de Oxígeno
          </h2>
          <Progress value={nivelOxigeno} className="w-full" />
          <span className="text-sm mt-1 block">{nivelOxigeno.toFixed(1)}%</span>
        </div>
      </Card>

      <Card>
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-2 flex items-center">
            <AirVent className="mr-2" />
            Control del Ventilador
          </h2>
          <input
            type="range"
            min="0"
            max="100"
            value={velocidadVentilador}
            onChange={(e) => setVelocidadVentilador(Number(e.target.value))}
            className="w-full"
            disabled={!encendido}
          />
          <span className="text-sm mt-1 block">{velocidadVentilador}%</span>
        </div>
      </Card>

      <Card>
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-2 flex items-center">
            <Battery className="mr-2" />
            Batería
          </h2>
          <Progress value={bateria} className="w-full" />
          <span className="text-sm mt-1 block">{bateria.toFixed(1)}%</span>
        </div>
      </Card>

      <Button 
        onClick={() => alert('Iniciando limpieza del filtro HEPA')} 
        disabled={!encendido}
        className="w-full"
      >
        Limpiar Filtro HEPA
      </Button>
    </div>
  )
}

