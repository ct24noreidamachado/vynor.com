import React from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'
import { Home, BarChart2, Settings } from 'lucide-react'

export default function BottomNavigation() {
  const router = useRouter()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg">
      <div className="flex justify-around items-center h-16">
        <Link href="/" className={`flex flex-col items-center ${router.pathname === '/' ? 'text-blue-500' : 'text-gray-500'}`}>
          <Home size={24} />
          <span className="text-xs mt-1">Inicio</span>
        </Link>
        <Link href="/history" className={`flex flex-col items-center ${router.pathname === '/history' ? 'text-blue-500' : 'text-gray-500'}`}>
          <BarChart2 size={24} />
          <span className="text-xs mt-1">Historial</span>
        </Link>
        <Link href="/settings" className={`flex flex-col items-center ${router.pathname === '/settings' ? 'text-blue-500' : 'text-gray-500'}`}>
          <Settings size={24} />
          <span className="text-xs mt-1">Ajustes</span>
        </Link>
      </div>
    </nav>
  )
}

