import Image from 'next/image'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Download, Share2 } from 'lucide-react'

export default function StorePreview() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-6">
          <div className="flex items-center mb-4">
            <div className="w-20 h-20 bg-blue-500 rounded-2xl mr-4 flex items-center justify-center text-white text-3xl font-bold">
              V
            </div>
            <div>
              <h1 className="text-2xl font-bold">VYNOR</h1>
              <p className="text-sm text-gray-600">TechInnovators Inc.</p>
              <div className="flex items-center mt-1">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-gray-300 fill-current" />
                <span className="ml-1 text-sm text-gray-600">(1,234)</span>
              </div>
            </div>
          </div>

          <div className="flex space-x-2 mb-4">
            <Button className="flex-1">
              <Download className="mr-2 h-4 w-4" /> Instalar
            </Button>
            <Button variant="outline">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>

          <div className="mb-4">
            <h2 className="text-lg font-semibold mb-2">Acerca de esta app</h2>
            <p className="text-sm text-gray-600">
              VYNOR es una aplicación innovadora diseñada para controlar tu Traje Respirador Inteligente. 
              Monitorea la calidad del aire, niveles de oxígeno y más, todo desde tu dispositivo móvil.
            </p>
          </div>

          <div className="mb-4">
            <h2 className="text-lg font-semibold mb-2">Capturas de pantalla</h2>
            <div className="flex space-x-2 overflow-x-auto">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="flex-shrink-0 w-40 h-80 bg-gray-200">
                  <CardContent className="p-2">
                    <div className="w-full h-full bg-gray-300 flex items-center justify-center text-gray-500">
                      Imagen {i}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">Información adicional</h2>
            <ul className="text-sm text-gray-600">
              <li>Versión: 1.0.0</li>
              <li>Actualizado el: 15 de enero de 2025</li>
              <li>Tamaño: 25M</li>
              <li>Descargas: 10,000+</li>
              <li>Clasificación: Para todos</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

