"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AirVent, Battery, Gauge, Thermometer, Settings, BarChart2, User } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Login } from "@/components/Login"

interface SensorData {
  tiempo: string
  calidadAire: number
  nivelOxigeno: number
  co2: number
  co: number
  nh3: number
  pulso: number
  spo2: number
}

export default function VynorApp() {
  const [user, setUser] = useState<string | null>(null)
  const [encendido, setEncendido] = useState(false)
  const [calidadAire, setCalidadAire] = useState(0)
  const [nivelOxigeno, setNivelOxigeno] = useState(0)
  const [velocidadVentilador, setVelocidadVentilador] = useState(0)
  const [bateria, setBateria] = useState(100)
  const [modoEmergencia, setModoEmergencia] = useState(false)
  const [historialDatos, setHistorialDatos] = useState<SensorData[]>([])
  const [co2, setCo2] = useState(0)
  const [co, setCo] = useState(0)
  const [nh3, setNh3] = useState(0)
  const [pulso, setPulso] = useState(0)
  const [spo2, setSpo2] = useState(0)

  useEffect(() => {
    if (encendido) {
      const interval = setInterval(() => {
        const nuevaCalidadAire = Math.random() * 100
        const nuevoNivelOxigeno = Math.random() * 100
        const nuevoCo2 = Math.random() * 1000
        const nuevoCo = Math.random() * 50
        const nuevoNh3 = Math.random() * 25
        const nuevoPulso = Math.floor(Math.random() * (100 - 60 + 1) + 60)
        const nuevoSpo2 = Math.floor(Math.random() * (100 - 95 + 1) + 95)

        setCalidadAire(nuevaCalidadAire)
        setNivelOxigeno(nuevoNivelOxigeno)
        setCo2(nuevoCo2)
        setCo(nuevoCo)
        setNh3(nuevoNh3)
        setPulso(nuevoPulso)
        setSpo2(nuevoSpo2)
        setBateria((prev) => Math.max(0, prev - 0.1))

        setHistorialDatos((prev) =>
          [
            ...prev,
            {
              tiempo: new Date().toLocaleTimeString(),
              calidadAire: nuevaCalidadAire,
              nivelOxigeno: nuevoNivelOxigeno,
              co2: nuevoCo2,
              co: nuevoCo,
              nh3: nuevoNh3,
              pulso: nuevoPulso,
              spo2: nuevoSpo2,
            },
          ].slice(-10),
        )
      }, 5000)
      return () => clearInterval(interval)
    }
  }, [encendido])

  const toggleEncendido = () => {
    setEncendido(!encendido)
    if (!encendido) {
      setVelocidadVentilador(50)
    } else {
      setVelocidadVentilador(0)
    }
  }

  const toggleModoEmergencia = () => {
    setModoEmergencia(!modoEmergencia)
    // Aquí iría la lógica para activar el modo de emergencia en el traje
  }

  const handleLogin = (email: string, password: string) => {
    // Aquí iría la lógica de autenticación real
    setUser(email)
  }

  if (!user) {
    return <Login onLogin={handleLogin} />
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6 text-center">Panel de Control VYNOR</h1>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="history">Historial</TabsTrigger>
          <TabsTrigger value="health">Salud</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Estado del Traje</span>
                  <Switch checked={encendido} onCheckedChange={toggleEncendido} />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{encendido ? "Activo" : "Inactivo"}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Gauge className="mr-2" />
                  Calidad del Aire
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={calidadAire} className="w-full" />
                <p className="text-right mt-2">{calidadAire.toFixed(1)}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Thermometer className="mr-2" />
                  Nivel de Oxígeno
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={nivelOxigeno} className="w-full" />
                <p className="text-right mt-2">{nivelOxigeno.toFixed(1)}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AirVent className="mr-2" />
                  Control del Ventilador
                </CardTitle>
              </CardHeader>
              <CardContent>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={velocidadVentilador}
                  onChange={(e) => setVelocidadVentilador(Number(e.target.value))}
                  className="w-full"
                  disabled={!encendido}
                />
                <p className="text-right mt-2">{velocidadVentilador}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Battery className="mr-2" />
                  Batería
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={bateria} className="w-full" />
                <p className="text-right mt-2">{bateria.toFixed(1)}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Modo de Emergencia</CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={toggleModoEmergencia}
                  variant={modoEmergencia ? "destructive" : "default"}
                  className="w-full"
                >
                  {modoEmergencia ? "Desactivar" : "Activar"} Modo de Emergencia
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart2 className="mr-2" />
                Historial de Datos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={historialDatos}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="tiempo" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="calidadAire" stroke="#8884d8" name="Calidad del Aire" />
                  <Line type="monotone" dataKey="nivelOxigeno" stroke="#82ca9d" name="Nivel de Oxígeno" />
                  <Line type="monotone" dataKey="co2" stroke="#ffc658" name="CO2" />
                  <Line type="monotone" dataKey="co" stroke="#ff8042" name="CO" />
                  <Line type="monotone" dataKey="nh3" stroke="#00C49F" name="NH3" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="health">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="mr-2" />
                Datos de Salud
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold">Pulso</h3>
                  <Progress value={pulso} max={120} className="w-full" />
                  <p className="text-right mt-2">{pulso} BPM</p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Saturación de Oxígeno (SpO2)</h3>
                  <Progress value={spo2} max={100} className="w-full" />
                  <p className="text-right mt-2">{spo2}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="mr-2" />
                Configuración
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Notificaciones</span>
                  <Switch />
                </div>
                <div className="flex justify-between items-center">
                  <span>Intervalo de actualización</span>
                  <select className="border rounded p-1">
                    <option>5 segundos</option>
                    <option>10 segundos</option>
                    <option>30 segundos</option>
                  </select>
                </div>
                <Button className="w-full" onClick={() => alert("Calibración iniciada")}>
                  Calibrar Sensores
                </Button>
                <Button className="w-full" onClick={() => setUser(null)}>
                  Cerrar sesión
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

